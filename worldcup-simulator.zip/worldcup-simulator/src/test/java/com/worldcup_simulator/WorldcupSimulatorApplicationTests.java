package com.worldcup_simulator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorldcupSimulatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
